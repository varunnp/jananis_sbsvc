<li role="presentation">
  	<a href="#inventory" aria-controls="inventory" role="tab" data-toggle="tab" class="inventory"><?php echo _l('settings_cron_inventorys'); ?></a>
</li>
